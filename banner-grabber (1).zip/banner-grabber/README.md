# Banner Grabber

IP manzil va portga ulanib, serverning birinchi javobini (banner) o'qiydigan o'quv vositasi.
Banner orqali serverda qaysi dastur va versiya ishlayotganini bilish mumkin (masalan, `SSH-2.0-OpenSSH_8.9`).

Loyiha uch xil muhit uchun yozilgan:

| Papka | Fayl | Muhit | Ishga tushirish |
|---|---|---|---|
| `python-scripting/` | `banner_grabber.py` | Linux (Python 3) | `python3 banner_grabber.py` |
| `bash-scripting/` | `banner_grabber.sh` | Linux (Bash) | `bash banner_grabber.sh` |
| `powershell-scripting/` | `banner_grabber.ps1` | Windows (PowerShell) | `powershell -ExecutionPolicy Bypass -File .\banner_grabber.ps1` |

## Imkoniyatlari
- IP va portni tekshirib qabul qiladi (noto'g'ri input qayta so'raladi)
- Portga ulanib, serverdan kelgan birinchi javobni o'qiydi va decode qiladi
- Xatolarni ushlaydi: yopiq port, timeout, tarmoq xatolari
- Natijani tartibli formatda chiqaradi
- Server o'zi gapirmasa (masalan, veb-server), oddiy HTTP `HEAD` so'rovi yuboradi

## Sinab ko'rish (o'z kompyuteringizda)
Ikkinchi terminalda soxta SSH server ishga tushiring:

    python3 -c "
    import socket
    s=socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
    s.bind(('127.0.0.1',2222)); s.listen(5)
    while True:
        c,_=s.accept(); c.sendall(b'SSH-2.0-OpenSSH_8.9p1 Ubuntu\r\n'); c.close()
    "

Keyin skriptda IP `127.0.0.1`, port `2222` kiriting.

## Ogohlantirish
Faqat o'z tizimingizda yoki ruxsat berilgan tizimlarda ishlating. Ruxsatsiz skanerlash qonunga zid bo'lishi mumkin.
