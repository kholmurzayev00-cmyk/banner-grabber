#!/usr/bin/env bash
# Banner Grabber (Bash) - IP va portga ulanib, serverning birinchi javobini (banner) o'qiydi.
# Faqat o'z yoki ruxsat berilgan tizimlar uchun!
TIMEOUT=3

valid_ip() {
    local ip=$1 o
    [[ $ip =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] || return 1
    IFS=. read -r -a parts <<< "$ip"
    for o in "${parts[@]}"; do
        (( 10#$o <= 255 )) || return 1
    done
    return 0
}

get_ip() {
    while true; do
        read -r -p "IP manzil kiriting (masalan 127.0.0.1): " ip
        [[ ${ip,,} == "localhost" ]] && ip="127.0.0.1"
        valid_ip "$ip" && return
        echo "[!] Noto'g'ri IPv4 manzil. Qaytadan urinib ko'ring."
    done
}

get_port() {
    while true; do
        read -r -p "Port raqami (1-65535): " port
        if [[ $port =~ ^[0-9]{1,5}$ ]] && (( 10#$port >= 1 && 10#$port <= 65535 )); then
            port=$((10#$port))
            return
        fi
        echo "[!] Port 1 dan 65535 gacha butun son bo'lishi kerak."
    done
}

# Natija: 0 = ochiq, 1 = yopiq, 2 = timeout, 3 = boshqa xato. Banner BANNER o'zgaruvchisida.
grab_banner() {
    local ip=$1 port=$2 line rc i=0
    BANNER=""

    # Avval ulanishni vaqt chegarasi bilan tekshiramiz
    timeout "$TIMEOUT" bash -c "exec 3<>/dev/tcp/$ip/$port" 2>/dev/null
    rc=$?
    [ $rc -eq 124 ] && return 2
    [ $rc -ne 0 ] && return 1

    exec 3<>"/dev/tcp/$ip/$port" 2>/dev/null || return 3

    if IFS= read -r -t "$TIMEOUT" line <&3; then
        BANNER+="$line"$'\n'                    # SSH, FTP, SMTP o'zi gapiradi
    else
        printf 'HEAD / HTTP/1.0\r\n\r\n' >&3    # HTTP kabi servislar so'ralishini kutadi
        IFS= read -r -t "$TIMEOUT" line <&3 && BANNER+="$line"$'\n'
    fi
    # Javobning qolgan qatorlarini (bo'lsa) o'qiymiz
    while (( i < 10 )) && IFS= read -r -t 0.5 line <&3; do
        BANNER+="$line"$'\n'
        i=$((i + 1))
    done
    exec 3<&- 3>&-
    BANNER=${BANNER//$'\r'/}
    return 0
}

echo "=================================================="
echo " BANNER GRABBER (faqat o'z/ruxsat berilgan tizimlar uchun)"
echo "=================================================="

while true; do
    get_ip
    get_port
    echo
    echo "[*] $ip:$port ga ulanilmoqda..."
    grab_banner "$ip" "$port"
    case $? in
        0)
            echo "--------------------------------------------------"
            echo " Manzil : $ip"
            echo " Port   : $port"
            echo " Holat  : OCHIQ"
            if [ -n "${BANNER//[$'\n ']/}" ]; then
                echo " Banner :"
                printf '%s\n' "$BANNER" | sed '/^$/d; s/^/   /'
            else
                echo " Banner : server javob qaytarmadi"
            fi
            echo "--------------------------------------------------" ;;
        1) echo "[X] Port $port YOPIQ (ulanish rad etildi yoki erishib bo'lmaydi)." ;;
        2) echo "[X] Timeout: $ip:$port $TIMEOUT soniyada javob bermadi." ;;
        *) echo "[X] Tarmoq xatosi yuz berdi." ;;
    esac

    echo
    read -r -p "Yana tekshiramizmi? (h/y): " again
    case ${again,,} in
        h|ha|y|yes) ;;
        *) echo "Dastur tugadi."; break ;;
    esac
done
