# Banner Grabber (PowerShell) - IP va portga ulanib, serverning birinchi javobini (banner) o'qiydi.
# Faqat o'z yoki ruxsat berilgan tizimlar uchun!
$Timeout = 3   # soniya

function Get-IPInput {
    while ($true) {
        $text = (Read-Host "IP manzil kiriting (masalan 127.0.0.1)").Trim()
        if ($text.ToLower() -eq "localhost") { $text = "127.0.0.1" }
        $parsed = $null
        if ($text -match '^\d{1,3}(\.\d{1,3}){3}$' -and [System.Net.IPAddress]::TryParse($text, [ref]$parsed)) {
            return $parsed.ToString()
        }
        Write-Host "[!] Noto'g'ri IPv4 manzil. Qaytadan urinib ko'ring." -ForegroundColor Yellow
    }
}

function Get-PortInput {
    while ($true) {
        $text = (Read-Host "Port raqami (1-65535)").Trim()
        if ($text -match '^\d{1,5}$' -and [int]$text -ge 1 -and [int]$text -le 65535) {
            return [int]$text
        }
        Write-Host "[!] Port 1 dan 65535 gacha butun son bo'lishi kerak." -ForegroundColor Yellow
    }
}

# Natija: Status = open / closed / timeout / error, Banner = server javobi
function Get-Banner($ip, $port) {
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($ip, $port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne($Timeout * 1000, $false)) {
            return @{ Status = "timeout"; Banner = "" }
        }
        try { $client.EndConnect($async) }
        catch { return @{ Status = "closed"; Banner = "" } }

        $stream = $client.GetStream()
        $stream.ReadTimeout = $Timeout * 1000
        $buffer = New-Object byte[] 1024
        $count = 0
        try {
            $count = $stream.Read($buffer, 0, $buffer.Length)      # SSH, FTP, SMTP o'zi gapiradi
        }
        catch [System.IO.IOException] {
            try {                                                  # HTTP so'ralishini kutadi
                $req = [System.Text.Encoding]::ASCII.GetBytes("HEAD / HTTP/1.0`r`n`r`n")
                $stream.Write($req, 0, $req.Length)
                $count = $stream.Read($buffer, 0, $buffer.Length)
            }
            catch { $count = 0 }
        }
        $banner = ""
        if ($count -gt 0) {
            $banner = [System.Text.Encoding]::UTF8.GetString($buffer, 0, $count).Trim()
        }
        return @{ Status = "open"; Banner = $banner }
    }
    catch {
        return @{ Status = "error"; Banner = $_.Exception.Message }
    }
    finally {
        $client.Close()
    }
}

Write-Host ("=" * 50)
Write-Host " BANNER GRABBER (faqat o'z/ruxsat berilgan tizimlar uchun)"
Write-Host ("=" * 50)

while ($true) {
    $ip = Get-IPInput
    $port = Get-PortInput
    Write-Host ""
    Write-Host "[*] ${ip}:${port} ga ulanilmoqda..."
    $r = Get-Banner $ip $port

    switch ($r.Status) {
        "open" {
            Write-Host ("-" * 50)
            Write-Host " Manzil : $ip"
            Write-Host " Port   : $port"
            Write-Host " Holat  : OCHIQ" -ForegroundColor Green
            if ($r.Banner) {
                Write-Host " Banner :"
                $r.Banner -split "`r?`n" | ForEach-Object { Write-Host "   $_" }
            }
            else {
                Write-Host " Banner : server javob qaytarmadi"
            }
            Write-Host ("-" * 50)
        }
        "closed"  { Write-Host "[X] Port $port YOPIQ (ulanish rad etildi)." -ForegroundColor Red }
        "timeout" { Write-Host "[X] Timeout: ${ip}:${port} $Timeout soniyada javob bermadi." -ForegroundColor Red }
        default   { Write-Host "[X] Tarmoq xatosi: $($r.Banner)" -ForegroundColor Red }
    }

    Write-Host ""
    $again = (Read-Host "Yana tekshiramizmi? (h/y)").Trim().ToLower()
    if ($again -notin @("h", "ha", "y", "yes")) {
        Write-Host "Dastur tugadi."
        break
    }
}
